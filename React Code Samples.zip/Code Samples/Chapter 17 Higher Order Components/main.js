import React from 'react';
import ReactDOM from 'react-dom';
import MyHOC from './MyHOC.jsx';

ReactDOM.render(<MyHOC />, document.getElementById('app'));