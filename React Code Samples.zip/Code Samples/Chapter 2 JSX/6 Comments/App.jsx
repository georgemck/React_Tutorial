import React from 'react';

class App extends React.Component {
    render() {
        return (
            <div>
                <h1>Header</h1>
                {
                    //End of the line Comment...
                }
                {/*Multi line comment...*/}
            </div>
        );
    }
}
export default App;